#include "azure_c_shared_utility/strings.h"
#include "azure_c_shared_utility/platform.h"
#include "system_pal.h"

extern const IO_INTERFACE_DESCRIPTION* tlsio_mbedtls_STM32Cube_get_interface_description(void);

const IO_INTERFACE_DESCRIPTION* platform_get_default_tlsio(void)
{
  return tlsio_mbedtls_STM32Cube_get_interface_description();
}


STRING_HANDLE platform_get_platform_info(void)
{
  return STRING_construct("(STM32F103)");
}
