#include "FreeRTOS.h"
#include "task.h"
#include "string.h"
#include "time.h"
#include "system_pal.h"


/********** memory utils ************/
void* pal_malloc( size_t size )
{
	return pvPortMalloc(size);
}

void pal_free(void* ptr)
{
	return vPortFree(ptr);
}

void* pal_calloc(size_t count, size_t size)
{
	void *p;

	/* allocate 'count' objects of size 'size' */
	p = pvPortMalloc(count * size);
	if (p) {
		/* zero the memory */
		memset(p, 0, count * size);
	}
	return p;
}

void* pal_realloc(void *mem, size_t newsize)
{
    if (newsize == 0) {
        vPortFree(mem);
        return NULL;
    }

    void *p;
    p = pvPortMalloc(newsize);
    if (p) {
        /* zero the memory */
        if (mem != NULL) {
            memcpy(p, mem, newsize);
            vPortFree(mem);
        }
    }
    return p;
}
/************************************/




/*************time utils*************/
extern volatile uint32_t millis_number;

time_t time(time_t * pointer)
{
	return (time_t)millis_number/1000 + 1572164065;
}
/************************************/





