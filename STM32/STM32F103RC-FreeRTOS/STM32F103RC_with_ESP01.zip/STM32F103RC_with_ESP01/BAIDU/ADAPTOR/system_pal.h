#ifndef __FREERTOS_PAL_H__
#define __FREERTOS_PAL_H__

#ifdef __cplusplus
extern "C"
{
#endif
#include "time.h"


/********** memory utils ************/
#undef 	malloc
#undef 	calloc
#undef 	realloc
#undef 	free
#define malloc 	pal_malloc
#define calloc 	pal_calloc
#define realloc pal_realloc
#define free 	pal_free

void* pal_malloc( size_t size );
void  pal_free(void* ptr);
void* pal_calloc(size_t count, size_t size);
void* pal_realloc(void *mem, size_t newsize);
/************************************/


/************* time utils *************/
time_t time(time_t *pointer);
/************************************/

#ifdef __cplusplus
}
#endif

#endif
