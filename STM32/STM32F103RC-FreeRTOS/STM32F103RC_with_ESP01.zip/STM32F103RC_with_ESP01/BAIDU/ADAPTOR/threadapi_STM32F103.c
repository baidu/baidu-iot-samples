#include <FreeRTOS.h>
#include <task.h>
#include <stdint.h>
#include <stdlib.h>
#ifdef UNUSED /* Prevent the redefinition from HAL to MS shared utilities */
#undef UNUSED
#endif 
#include "azure_c_shared_utility/threadapi.h"
#include "azure_c_shared_utility/xlogging.h"
#include "system_pal.h"


void ThreadAPI_Sleep(unsigned int milliseconds)
{
  vTaskDelay(milliseconds) ;
}
