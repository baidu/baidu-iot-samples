#include <stdlib.h>
/*
#include "mbedtls/config.h"
#include "mbedtls/debug.h"
#include "mbedtls/ssl.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/error.h"
#include "mbedtls/certs.h"
#include "mbedtls/entropy_poll.h"*/

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "azure_c_shared_utility/optimize_size.h"
#include "azure_c_shared_utility/tlsio.h"
#include "system_pal.h"


/* We can not afford the memory consumption of TLS on STM32F103RC, as the memory size of it is only 48KB.
	To use TLS to connect to Baidu iothub, we need at least 60KB of RAM.
 */
const IO_INTERFACE_DESCRIPTION* tlsio_mbedtls_STM32Cube_get_interface_description(void)
{
    //return &tlsio_mbedtls_interface_description;
	return NULL;
}

