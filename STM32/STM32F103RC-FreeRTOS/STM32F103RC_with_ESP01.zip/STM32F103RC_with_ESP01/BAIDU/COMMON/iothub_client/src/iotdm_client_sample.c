/*
* Copyright (c) 2017 Baidu, Inc. All Rights Reserved.
*
* Licensed to the Apache Software Foundation (ASF) under one or more
* contributor license agreements.  See the NOTICE file distributed with
* this work for additional information regarding copyright ownership.
* The ASF licenses this file to You under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with
* the License.  You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include "led.h"
#include <azure_c_shared_utility/platform.h>
#include <azure_c_shared_utility/threadapi.h>
#include <azure_c_shared_utility/buffer_.h>
#include <azure_c_shared_utility/tickcounter.h>
#include "system_pal.h"

#include "iotdm_callback.h"
#include "iotdm_client.h"
#include "iotdm_client_sample.h"

// Should include serializer to operate shadow with device model.
#include "serializer.h"

#define         SPLIT               "--------------------------------------------------------------------------------------------"


// Please set the device client data and security which are shown as follow.
// The endpoint address your device should cnnect, which is like
// 1. "tcp://xxxxxx.mqtt.iot.xx.baidubce.com:1883" or
// 2. "ssl://xxxxxx.mqtt.iot.xx.baidubce.com:1884"
#define         ADDRESS             "tcp://bdypdp2.mqtt.iot.gz.baidubce.com:1883"

// The device name you created in device management service.
#define         DEVICE              "myMonitor"

// The username you can find on the device connection configuration web,
// and the format is like "xxxxxx/xxxxx"
#define         USERNAME            "bdypdp2/myMonitor"

// The key (password) you can find on the device connection configuration web.
#define         PASSWORD            "ae76x4w1ayi6n6i9"

BEGIN_NAMESPACE(BaiduIotMqttThing);

DECLARE_MODEL(BaiduSerializableIotMqttDev_t,
    WITH_DATA(float, temperature),
    WITH_DATA(float, humidity),
    WITH_DATA(int, led)
  );

END_NAMESPACE(BaiduIotMqttThing);

static int ledState = 0;
    
static void Log(const char* message)
{
    printf("%s\r\n", message);
}

static void Log4Int(const int value)
{
    printf("%d\r\n", value);
}

static void LogCode(const int code)
{
    Log4Int(code);
}

static void LogVersion(const int version)
{
    Log4Int(version);
}

static void LogAcceptedMessage(const SHADOW_ACCEPTED* accepted)
{
    Log("ProfileVersion:");
    LogVersion(accepted->profileVersion);

    JSON_Value* value = json_object_get_wrapping_value(accepted->reported);
    char* encoded = json_serialize_to_string(value);
    Log("Reported:");
    Log(encoded);
    json_free_serialized_string(encoded);

    value = json_object_get_wrapping_value(accepted->desired);
    encoded = json_serialize_to_string(value);
    Log("Desired:");
    Log(encoded);
    json_free_serialized_string(encoded);

    value = json_object_get_wrapping_value(accepted->lastUpdateTime);
    encoded = json_serialize_to_string(value);
    Log("LastUpdateTime:");
    Log(encoded);
    json_free_serialized_string(encoded);
}

static void HandleAccepted(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ACCEPTED* accepted, void* callbackContext)
{
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);

    LogAcceptedMessage(accepted);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }
}

static void HandleRejected(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ERROR* error, void* callbackContext)
{
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);
    Log("Code:");
    LogCode(error->code);
    Log("Message:");
    Log(error->message);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }
}

static void HandleGetAccepted(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ACCEPTED* accepted, void* callbackContext)
{
    Log("Received a message for shadow get accepted.");
    HandleAccepted(messageContext, accepted, callbackContext);

    Log(SPLIT);
}

static void HandleGetRejected(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ERROR* error, void* callbackContext)
{
    Log("Received a message for shadow get rejected.");
    HandleRejected(messageContext, error, callbackContext);

    Log(SPLIT);
}

static void HandleUpdateRejected(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ERROR* error, void* callbackContext)
{
    Log("Received a message for shadow update rejected.");
    HandleRejected(messageContext, error, callbackContext);

    Log(SPLIT);
}

static void HandleUpdateAccepted(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ACCEPTED* accepted, void* callbackContext)
{
    Log("Received a message for shadow update accepted.");
    HandleAccepted(messageContext, accepted, callbackContext);

    Log(SPLIT);
}

static void HandleUpdateDocuments(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_DOCUMENTS* documents, void* callbackContext)
{
    Log("Received a message for shadow update documents.");
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);

    Log("ProfileVersion:");
    LogVersion(documents->profileVersion);

    JSON_Value* value = json_object_get_wrapping_value(documents->current);
    char* encoded = json_serialize_to_string(value);
    Log("Current:");
    Log(encoded);
    json_free_serialized_string(encoded);

    value = json_object_get_wrapping_value(documents->previous);
    encoded = json_serialize_to_string(value);
    Log("Previous:");
    Log(encoded);
    json_free_serialized_string(encoded);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }

    Log(SPLIT);
}

static void HandleUpdateSnapshot(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_SNAPSHOT* snapshot, void* callbackContext)
{
    Log("Received a message for shadow update snapshot.");
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);

    Log("ProfileVersion:");
    LogVersion(snapshot->profileVersion);

    JSON_Value* value = json_object_get_wrapping_value(snapshot->reported);
    char* encoded = json_serialize_to_string(value);
    Log("Reported:");
    Log(encoded);
    json_free_serialized_string(encoded);

    value = json_object_get_wrapping_value(snapshot->lastUpdateTime);
    encoded = json_serialize_to_string(value);
    Log("LastUpdateTime:");
    Log(encoded);
    json_free_serialized_string(encoded);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }

    Log(SPLIT);
}

static void HandleDeleteAccepted(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ACCEPTED* accepted, void* callbackContext)
{
    Log("Received a message for shadow delete accepted.");
    HandleAccepted(messageContext, accepted, callbackContext);

    Log(SPLIT);
}

static void HandleDeleteRejected(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ERROR* error, void* callbackContext)
{
    Log("Received a message for shadow delete rejected.");
    HandleRejected(messageContext, error, callbackContext);

    Log(SPLIT);
}

static void HandleDelta(const SHADOW_MESSAGE_CONTEXT* messageContext, const JSON_Object* desired, void* callbackContext)
{
    Log("Received a message for shadow delta");
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);

    JSON_Value* value = json_object_get_wrapping_value(desired);
    char* encoded = json_serialize_to_string(value);
    Log("Payload:");
    Log(encoded);
    json_free_serialized_string(encoded);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }

    //only track led state in this sample
    int onOff = (int)json_object_get_number(desired, "led");
    printf("get onOff value: %d\n", onOff);
    
    if (onOff == 0) {
        ledState = 0;
        LED1 = 0;
    } else {
        ledState = 1;
        LED1 = 1;
    }
    
    IOTDM_CLIENT_HANDLE handle = (IOTDM_CLIENT_HANDLE)callbackContext;
    int result = iotdm_client_update_shadow(handle, messageContext->device, messageContext->requestId, 0, value, NULL);
    if (0 == result)
    {
        Log("Have done for the device controller request, and corresponding shadow is updated.");
    }
    else
    {
        LogError("Failure: failed to update device shadow.");
    }
    
    
    Log(SPLIT);
}

int iotdm_client_run(void)
{
    Log("The device management edge simulator is starting ...");
    if (SERIALIZER_OK != serializer_init(NULL))
    {
        Log("serializer_init failed");
        return __FAILURE__;
    }

    IOTDM_CLIENT_HANDLE handle = iotdm_client_init(ADDRESS, DEVICE);
    if (NULL == handle)
    {
        Log("iotdm_client_init failed");
        return __FAILURE__;
    }

    iotdm_client_register_delta(handle, HandleDelta, handle);
    iotdm_client_register_get_accepted(handle, HandleGetAccepted, handle);
    iotdm_client_register_get_rejected(handle, HandleGetRejected, handle);
    iotdm_client_register_update_accepted(handle, HandleUpdateAccepted, handle);
    iotdm_client_register_update_rejected(handle, HandleUpdateRejected, handle);
    //iotdm_client_register_update_documents(handle, HandleUpdateDocuments, handle);
    //iotdm_client_register_update_snapshot(handle, HandleUpdateSnapshot, handle);
    iotdm_client_register_delete_accepted(handle, HandleDeleteAccepted, handle);
    iotdm_client_register_delete_rejected(handle, HandleDeleteRejected, handle);

    IOTDM_CLIENT_OPTIONS options;
    options.cleanSession = true;
    options.clientId = DEVICE;
    options.username = USERNAME;
    options.password = PASSWORD;
    options.keepAliveInterval = 60;
    options.retryTimeoutInSeconds = 300;

    if (0 != iotdm_client_connect(handle, &options))
    {
        iotdm_client_deinit(handle);
        Log("iotdm_client_connect failed");
        return __FAILURE__;
    }

    Log("connect success!");
    // Subscribe the topics.
    iotdm_client_dowork(handle);

    // Sample: get device shadow
    if (0 == iotdm_client_get_shadow(handle, DEVICE, "123456789"))
    {
        Log("Succeeded to get device shadow");
    }
    else
    {
        Log("Failed to get device shadow");
    }

    // Sample: use 'serializer' to encode device model to binary and update the device shadow.
    BaiduSerializableIotMqttDev_t* mdl = CREATE_MODEL_INSTANCE(BaiduIotMqttThing, BaiduSerializableIotMqttDev_t, true);
    unsigned char* reported;
    size_t reportedSize;
    

    TICK_COUNTER_HANDLE tickCounterHandle = tickcounter_create();
    tickcounter_ms_t currentTime, lastSendTime;
    tickcounter_get_current_ms(tickCounterHandle, &lastSendTime);
    bool needSubscribeTopic = false;
    do
    {
        iotdm_client_dowork(handle);
        printf("heap size: %d\r\n", xPortGetFreeHeapSize());
        tickcounter_get_current_ms(tickCounterHandle, &currentTime);
        
        // send a update message every 5 seconds
        if ((currentTime - lastSendTime) / 1000 > 5)
        {
            // fetch sensor values
            mdl->temperature = 20 + rand() % 10;
            mdl->humidity = 50 + rand() % 10;
            mdl->led = ledState;
            SERIALIZE(&reported, &reportedSize, *mdl);
            
            // note: SERIALIZE not end with '\0'
            char* reportedString = malloc(sizeof(char) * (reportedSize + 1));
            reportedString[reportedSize] = '\0';
            memcpy(reportedString, reported, reportedSize);
            free(reported);

            if (0 == iotdm_client_update_shadow_with_binary(handle, DEVICE, "123456", 0, reportedString, NULL))
            {
                Log("Succeeded to update device shadow with binary");
            }
            else
            {
                Log("Failed to update device shadow with binary");
            }
            free(reportedString);
            lastSendTime = currentTime;
        }
        ThreadAPI_Sleep(10);
    } while (true);
    
    DESTROY_MODEL_INSTANCE(mdl);
    iotdm_client_deinit(handle);
    serializer_deinit();
    platform_deinit();

    return 0;

#ifdef _CRT_DBG_MAP_ALLOC
    _CrtDumpMemoryLeaks();
#endif
}

