#ifndef __COMMON_H
#define __COMMON_H

#include "string.h"
#include "stdint.h"
#include "stm32f10x.h"
#include <stdbool.h>

#define FALSE   false
#define TRUE    true

void delay (unsigned int count);
void sysTickInit(void);
uint32_t millis(void);

#endif
