#include "delay.h"
#if SYSTEM_SUPPORT_OS
#include "FreeRTOS.h"
#include "task.h"
#endif

extern void xPortSysTickHandler(void);

void SysTick_Handler(void)
{	
    extern uint32_t millis_number;
    if(xTaskGetSchedulerState()!=taskSCHEDULER_NOT_STARTED)
    {
        xPortSysTickHandler();	
    }
    millis_number++;
}
	   
void delay_init()
{
	u32 reload;
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
	reload=SystemCoreClock/1000000;
	reload*=1000000/configTICK_RATE_HZ;

	SysTick->CTRL|=SysTick_CTRL_TICKINT_Msk;
	SysTick->LOAD=reload;
	SysTick->CTRL|=SysTick_CTRL_ENABLE_Msk;
}								    




