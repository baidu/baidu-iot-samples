#include "led.h"
#include "delay.h"
#include "sys.h"
#include "FreeRTOS.h"
#include "task.h"
#include "usart2.h"
#include "ESP8266Client.h"
#include "ESP8266WIFI.h"
#include "common.h"
#include "stdlib.h"
#include "iotdm_client_sample.h"

#define START_TASK_PRIO		1
#define START_STK_SIZE 		128  
TaskHandle_t StartTask_Handler;
void start_task(void *pvParameters);

#define LED0_TASK_PRIO		3
#define LED0_STK_SIZE 		50  
TaskHandle_t LED0Task_Handler;
void led0_task(void *pvParameters);

#define ESP8266_TASK_PRIO		3
#define ESP8266_STK_SIZE    1024
TaskHandle_t ESP8266Task_Handler;
void esp8266_task(void *pvParameters);

#define 	CUR_AP_SSID 		"Honor8"
#define		CUR_AP_PWD			"243587123"



int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
	delay_init();
	USART1_Configuration();
	USART2_Configuration();
	LED_Init();
	    
    xTaskCreate((TaskFunction_t )start_task,
                (const char*    )"start_task",
                (uint16_t       )START_STK_SIZE,
                (void*          )NULL,
                (UBaseType_t    )START_TASK_PRIO,
                (TaskHandle_t*  )&StartTask_Handler);          
    vTaskStartScheduler();
}

void start_task(void *pvParameters)
{
    taskENTER_CRITICAL();
	
    xTaskCreate((TaskFunction_t )led0_task,     	
                (const char*    )"led0_task",   	
                (uint16_t       )LED0_STK_SIZE, 
                (void*          )NULL,				
                (UBaseType_t    )LED0_TASK_PRIO,	
                (TaskHandle_t*  )&LED0Task_Handler);   

    xTaskCreate((TaskFunction_t )esp8266_task,     
                (const char*    )"esp8266_task",   
                (uint16_t       )ESP8266_STK_SIZE, 
                (void*          )NULL,
                (UBaseType_t    )ESP8266_TASK_PRIO,
                (TaskHandle_t*  )&ESP8266Task_Handler);
		
								
    vTaskDelete(StartTask_Handler);
    taskEXIT_CRITICAL();
}

void led0_task(void *pvParameters)
{
    while(1)
    {
        LED0=~LED0;
        vTaskDelay(500);
    }
}   

void esp8266_task(void *pvParameters)
{
		printf("==> esp8266_task\r\n");
	// һֱ���͡�AT������ ֱ���з���
		while (1) {
			if (TRUE == esp8266Test()) {
				break;
			}
		}
		if (FALSE == esp8266SetMode(ESP8266_MODE_STA)) {
			printf("esp8266SetMode failed\r\n");
			return;
		}
		printf("Set STATION mode success!\r\n");
		if (FALSE == esp8266Connect(CUR_AP_SSID, CUR_AP_PWD)) {
			printf("esp8266Connect failed\r\n");
			return;
		}
		printf("connect AP [%s] success!\r\n", CUR_AP_SSID);
		/* Working application */
        iotdm_client_run();
}
