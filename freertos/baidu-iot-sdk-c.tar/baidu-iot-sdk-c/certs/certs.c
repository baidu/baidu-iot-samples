/*
* Copyright (c) 2017 Baidu, Inc. All Rights Reserved.
*
* Licensed to the Apache Software Foundation (ASF) under one or more
* contributor license agreements.  See the NOTICE file distributed with
* this work for additional information regarding copyright ownership.
* The ASF licenses this file to You under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with
* the License.  You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

/* This file contains cert trust chain needed to communicate with Baidu (IoT Hub) */

#include "certs.h"

const char certificates[] =
// add trust external ca root
"-----BEGIN CERTIFICATE-----\r\n"
        "MIIGCDCCA/CgAwIBAgIQKy5u6tl1NmwUim7bo3yMBzANBgkqhkiG9w0BAQwFADCB\r\n"
        "hTELMAkGA1UEBhMCR0IxGzAZBgNVBAgTEkdyZWF0ZXIgTWFuY2hlc3RlcjEQMA4G\r\n"
        "A1UEBxMHU2FsZm9yZDEaMBgGA1UEChMRQ09NT0RPIENBIExpbWl0ZWQxKzApBgNV\r\n"
        "BAMTIkNPTU9ETyBSU0EgQ2VydGlmaWNhdGlvbiBBdXRob3JpdHkwHhcNMTQwMjEy\r\n"
        "MDAwMDAwWhcNMjkwMjExMjM1OTU5WjCBkDELMAkGA1UEBhMCR0IxGzAZBgNVBAgT\r\n"
        "EkdyZWF0ZXIgTWFuY2hlc3RlcjEQMA4GA1UEBxMHU2FsZm9yZDEaMBgGA1UEChMR\r\n"
        "Q09NT0RPIENBIExpbWl0ZWQxNjA0BgNVBAMTLUNPTU9ETyBSU0EgRG9tYWluIFZh\r\n"
        "bGlkYXRpb24gU2VjdXJlIFNlcnZlciBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEP\r\n"
        "ADCCAQoCggEBAI7CAhnhoFmk6zg1jSz9AdDTScBkxwtiBUUWOqigwAwCfx3M28Sh\r\n"
        "bXcDow+G+eMGnD4LgYqbSRutA776S9uMIO3Vzl5ljj4Nr0zCsLdFXlIvNN5IJGS0\r\n"
        "Qa4Al/e+Z96e0HqnU4A7fK31llVvl0cKfIWLIpeNs4TgllfQcBhglo/uLQeTnaG6\r\n"
        "ytHNe+nEKpooIZFNb5JPJaXyejXdJtxGpdCsWTWM/06RQ1A/WZMebFEh7lgUq/51\r\n"
        "UHg+TLAchhP6a5i84DuUHoVS3AOTJBhuyydRReZw3iVDpA3hSqXttn7IzW3uLh0n\r\n"
        "c13cRTCAquOyQQuvvUSH2rnlG51/ruWFgqUCAwEAAaOCAWUwggFhMB8GA1UdIwQY\r\n"
        "MBaAFLuvfgI9+qbxPISOre44mOzZMjLUMB0GA1UdDgQWBBSQr2o6lFoL2JDqElZz\r\n"
        "30O0Oija5zAOBgNVHQ8BAf8EBAMCAYYwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNV\r\n"
        "HSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwGwYDVR0gBBQwEjAGBgRVHSAAMAgG\r\n"
        "BmeBDAECATBMBgNVHR8ERTBDMEGgP6A9hjtodHRwOi8vY3JsLmNvbW9kb2NhLmNv\r\n"
        "bS9DT01PRE9SU0FDZXJ0aWZpY2F0aW9uQXV0aG9yaXR5LmNybDBxBggrBgEFBQcB\r\n"
        "AQRlMGMwOwYIKwYBBQUHMAKGL2h0dHA6Ly9jcnQuY29tb2RvY2EuY29tL0NPTU9E\r\n"
        "T1JTQUFkZFRydXN0Q0EuY3J0MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5jb21v\r\n"
        "ZG9jYS5jb20wDQYJKoZIhvcNAQEMBQADggIBAE4rdk+SHGI2ibp3wScF9BzWRJ2p\r\n"
        "mj6q1WZmAT7qSeaiNbz69t2Vjpk1mA42GHWx3d1Qcnyu3HeIzg/3kCDKo2cuH1Z/\r\n"
        "e+FE6kKVxF0NAVBGFfKBiVlsit2M8RKhjTpCipj4SzR7JzsItG8kO3KdY3RYPBps\r\n"
        "P0/HEZrIqPW1N+8QRcZs2eBelSaz662jue5/DJpmNXMyYE7l3YphLG5SEXdoltMY\r\n"
        "dVEVABt0iN3hxzgEQyjpFv3ZBdRdRydg1vs4O2xyopT4Qhrf7W8GjEXCBgCq5Ojc\r\n"
        "2bXhc3js9iPc0d1sjhqPpepUfJa3w/5Vjo1JXvxku88+vZbrac2/4EjxYoIQ5QxG\r\n"
        "V/Iz2tDIY+3GH5QFlkoakdH368+PUq4NCNk+qKBR6cGHdNXJ93SrLlP7u3r7l+L4\r\n"
        "HyaPs9Kg4DdbKDsx5Q5XLVq4rXmsXiBmGqW5prU5wfWYQ//u+aen/e7KJD2AFsQX\r\n"
        "j4rBYKEMrltDR5FL1ZoXX/nUh8HCjLfn4g8wGTeGrODcQgPmlKidrv0PJFGUzpII\r\n"
        "0fxQ8ANAe4hZ7Q7drNJ3gjTcBpUC2JD5Leo31Rpg0Gcg19hCC0Wvgmje3WYkN5Ap\r\n"
        "lBlGGSW4gNfL1IYoakRwJiNiqZ+Gb7+6kHDSVneFeO/qJakXzlByjAA6quPbYzSf\r\n"
        "+AZxAeKCINT+b72x\r\n"
        "-----END CERTIFICATE-----\r\n"
;

// add your client cert of the principal
const char client_cert[] =
 		"-----BEGIN CERTIFICATE-----\n"
		"MIIEGDCCAwCgAwIBAgIITbIH0/YmafEwDQYJKoZIhvcNAQELBQAwMzEWMBQGA1UE\n"
		"AwwNaW90LmJhaWR1LmNvbTEMMAoGA1UECwwDQkNFMQswCQYDVQQGEwJDTjAeFw0x\n"
		"ODA0MTYwOTE5NTlaFw0zODAzMTEwMjU2NDRaMGgxDjAMBgNVBAoMBUJhaWR1MQsw\n"
		"CQYDVQQGEwJDTjE7MDkGA1UEAwwycGt0ZXN0LmJqdGVzdC5mZGFjZjk0My04YTg5\n"
		"LTQ3ZDItYTY5NS1lZTFiYzlkZjQzNDAxDDAKBgNVBAsMA0JDRTCCASIwDQYJKoZI\n"
		"hvcNAQEBBQADggEPADCCAQoCggEBAIyU06eiJLc91o8fsZyf7V3s4Hcw81ZsSoVS\n"
		"SIKub5RMm7bPltdvracAoleRC6Fgvp/0xAVVICraUv2V4EFlceVNZEoRu6gBy+J8\n"
		"QMQ55bogcgGQWHW4y+3/Yw9QOEf76XH5owOextfSW7zFMa1bE8xB0a+GSl6X/q8o\n"
		"BxpNbUN1FpYYzYvg1bL0sBxlgOPzE+3Ze8QbSk0nm4EGKTxe8YZUSbvPEKaiQ/+w\n"
		"B/in882ipRoNPBs0NRFd1D1elqh3mjb3xa5bOkPrszunjhOzJKffQ5jHfPtbQCV4\n"
		"lfTiS81DRqmHPSumBigEQms2Fm2wrBamvmNdD1zYMiRWWoyBonUCAwEAAaOB+jCB\n"
		"9zAdBgNVHQ4EFgQU63fZ93kpJKsO5ZmKDNW2ULvlXtkwDAYDVR0TAQH/BAIwADAf\n"
		"BgNVHSMEGDAWgBTdCOQVn9b8/AFr+41Kt9XbBXCPYzB4BgNVHR8EcTBvMG2ga6Bp\n"
		"hmdodHRwOi8vcGtpLmlvdi5iYWlkdWJjZS5jb20vdjEvcGtpL2NybD9jbWQ9Y3Js\n"
		"JmZvcm1hdD1QRU0maXNzdWVyPUNOJTNEaW90LmJhaWR1LmNvbSUyQ09VJTNEQkNF\n"
		"JTJDQyUzRENOMA4GA1UdDwEB/wQEAwID+DAdBgNVHSUEFjAUBggrBgEFBQcDAgYI\n"
		"KwYBBQUHAwQwDQYJKoZIhvcNAQELBQADggEBAKpaJsXg2TfAfJkaVkUYY3+jmhKi\n"
		"8tDeJTMkBJVMLw171H2yF1qbtn/ENshWXPKoRD/5OMak3Fbuaf2ln95a82fPn+XL\n"
		"wJUEa+xj+8I+hZQU+llJoja+Dd795iEz9/FI+aEOqOJeIkj2PTYrtMjVoqwHRB3q\n"
		"Oo/8hQg0x8MOjznsRzs3GL4sC2bGPjB0GgPnFafLK/RgjPp3p9y0qLtmahQHRp8+\n"
		"z8NsYiGQVKmrewAiWaescxvKp7BX/f73um/+H8HL+5lF9hQyW8kjIuY4BAtDncHy\n"
		"MjFyCTwiUwcDN1+SByaFGQmCPwJZhA1Fvoy/FWe5ONRyxDvdrmm1gxRksI8=\n"
		"-----END CERTIFICATE-----\n";
// add your client private key of the principal
const char client_key[] =
 		"-----BEGIN RSA PRIVATE KEY-----\n"
		"MIIEpAIBAAKCAQEAjJTTp6Iktz3Wjx+xnJ/tXezgdzDzVmxKhVJIgq5vlEybts+W\n"
		"12+tpwCiV5ELoWC+n/TEBVUgKtpS/ZXgQWVx5U1kShG7qAHL4nxAxDnluiByAZBY\n"
		"dbjL7f9jD1A4R/vpcfmjA57G19JbvMUxrVsTzEHRr4ZKXpf+rygHGk1tQ3UWlhjN\n"
		"i+DVsvSwHGWA4/MT7dl7xBtKTSebgQYpPF7xhlRJu88QpqJD/7AH+KfzzaKlGg08\n"
		"GzQ1EV3UPV6WqHeaNvfFrls6Q+uzO6eOE7Mkp99DmMd8+1tAJXiV9OJLzUNGqYc9\n"
		"K6YGKARCazYWbbCsFqa+Y10PXNgyJFZajIGidQIDAQABAoIBAQCAs7P+EWypsdxf\n"
		"lbWGXcfzKGzr0g3FPkkPO6CUu1v9mhEo0W4Yd+60KNl3b5wFN0vtpyladG+Jq+00\n"
		"qeTwGg6mzi6VvRxfGJ3vELA+tX7C4vdcxSinRfK1Rg0LtPaBuHglV1VNeCw05CoG\n"
		"bUYonmxGoK92kWw+o8qP0waFpwL0ML9f08IbJAO/FgO0hgGZr6IcIBU3UfwIAlGT\n"
		"UeVE4WtWn0LJAYoNwshW2NqZ4jq4DdAlWb1263sV86ykGtZYKANM92GQI2Id63s3\n"
		"EwRvsCxkozmTp3iX5CU5lLrmkt6pHFLQeXXyuuEys2iNRE9nsOM/eNv1IRqxVLO3\n"
		"L6+/rOK1AoGBAMPJKCvMN6IMxcrQS1JA1CWY/rUOIbz7LEk+xo74S23r+MJxHuph\n"
		"p1jxy4cHLxDZr1bDHLp/4B/KftJNCJ7X+f51lI7gkw8C1MKzBZv6MRrfsLLQfUni\n"
		"sgAcZVZWFevExAK9shAP3JcJdb373SMTjS9W+nA2mdlUkaT/MDDLdPwjAoGBALfR\n"
		"P7HcPTGsWGqMqdwaTGB7A/Yp7UQ/hJ9Y9DppDIC9Y6AA6RjuK3gN8WZuTPU4zgSk\n"
		"0QOnc1L7BbivI1Ut4A6jLi9PKZTueF/NuQ+KmGH9MYevq6njqSw/W1iGIiCExBRf\n"
		"oXy1Pr1iy9vwR8P8rtodv/o7KZrhC6cxq5R7EWSHAoGAB5dMDG6tlYXjQVrUIMtM\n"
		"rmyBK6nxmu8uJ2Tcs/xiiE+G5JsYNMQ2hddSKdkYdRHLn5SPD5gXq4PhaOv9spLz\n"
		"KW+LpAKHESTt9OKWDBcmQkF8C2LUCMJWXnS7ZR6PWQXXB7gtKDxFNEH0o7oZN9vx\n"
		"NG2t5h3n1ypVP015o9qvnXsCgYEAnSE8B3gyv0GKGxq/IK1CWL8PdeAFOG/rmKNb\n"
		"soqV6375qI7eszb05Z1Vm6/yDTVPttyE51C+3lJCY8sisu+SNjD7i+lprCvlrk+X\n"
		"QFfDRxA+xLRAU+uOc4p9NUED7zROwPO2gXoVdaL8jLfrQPfBKCaCMw9b009IvNVS\n"
		"zIwfJAUCgYBHal6L2jrRfiYmaVcBTlezqaG5CwNpktgdwYaOVWQhBtDWsiB+UF6t\n"
		"TH/fzTlfLjUt29zVaGHdEs/le+H7ojZkuoKUeW5JcZ5/CPzthBQ5IuSWtdoLY+u8\n"
		"+QFEgVQXnJ6lbisXt8/Nps0JyOxmIIBaqPwKPCU2niQDwC0vKKlWLQ==\n"
		"-----END RSA PRIVATE KEY-----\n";

const char bos_root_ca[] = "-----BEGIN CERTIFICATE-----\n"
    "MIIE0zCCA7ugAwIBAgIQGNrRniZ96LtKIVjNzGs7SjANBgkqhkiG9w0BAQUFADCB\n"
    "yjELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQL\n"
    "ExZWZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJp\n"
    "U2lnbiwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxW\n"
    "ZXJpU2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0\n"
    "aG9yaXR5IC0gRzUwHhcNMDYxMTA4MDAwMDAwWhcNMzYwNzE2MjM1OTU5WjCByjEL\n"
    "MAkGA1UEBhMCVVMxFzAVBgNVBAoTDlZlcmlTaWduLCBJbmMuMR8wHQYDVQQLExZW\n"
    "ZXJpU2lnbiBUcnVzdCBOZXR3b3JrMTowOAYDVQQLEzEoYykgMjAwNiBWZXJpU2ln\n"
    "biwgSW5jLiAtIEZvciBhdXRob3JpemVkIHVzZSBvbmx5MUUwQwYDVQQDEzxWZXJp\n"
    "U2lnbiBDbGFzcyAzIFB1YmxpYyBQcmltYXJ5IENlcnRpZmljYXRpb24gQXV0aG9y\n"
    "aXR5IC0gRzUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCvJAgIKXo1\n"
    "nmAMqudLO07cfLw8RRy7K+D+KQL5VwijZIUVJ/XxrcgxiV0i6CqqpkKzj/i5Vbex\n"
    "t0uz/o9+B1fs70PbZmIVYc9gDaTY3vjgw2IIPVQT60nKWVSFJuUrjxuf6/WhkcIz\n"
    "SdhDY2pSS9KP6HBRTdGJaXvHcPaz3BJ023tdS1bTlr8Vd6Gw9KIl8q8ckmcY5fQG\n"
    "BO+QueQA5N06tRn/Arr0PO7gi+s3i+z016zy9vA9r911kTMZHRxAy3QkGSGT2RT+\n"
    "rCpSx4/VBEnkjWNHiDxpg8v+R70rfk/Fla4OndTRQ8Bnc+MUCH7lP59zuDMKz10/\n"
    "NIeWiu5T6CUVAgMBAAGjgbIwga8wDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8E\n"
    "BAMCAQYwbQYIKwYBBQUHAQwEYTBfoV2gWzBZMFcwVRYJaW1hZ2UvZ2lmMCEwHzAH\n"
    "BgUrDgMCGgQUj+XTGoasjY5rw8+AatRIGCx7GS4wJRYjaHR0cDovL2xvZ28udmVy\n"
    "aXNpZ24uY29tL3ZzbG9nby5naWYwHQYDVR0OBBYEFH/TZafC3ey78DAJ80M5+gKv\n"
    "MzEzMA0GCSqGSIb3DQEBBQUAA4IBAQCTJEowX2LP2BqYLz3q3JktvXf2pXkiOOzE\n"
    "p6B4Eq1iDkVwZMXnl2YtmAl+X6/WzChl8gGqCBpH3vn5fJJaCGkgDdk+bW48DW7Y\n"
    "5gaRQBi5+MHt39tBquCWIMnNZBU4gcmU7qKEKQsTb47bDN0lAtukixlE0kF6BWlK\n"
    "WE9gyn6CagsCqiUXObXbf+eEZSqVir2G3l6BFoMtEMze/aiCKm0oHw0LxOXnGiYZ\n"
    "4fQRbxC1lfznQgUy286dUV4otp6F01vvpX1FQHKOtw5rDgb7MzVIcbidJ4vEZV8N\n"
    "hnacRHr2lVz2XTIIM6RUthg/aFzyQkqFOFSDX9HoLPKsEdao7WNq\n"
    "-----END CERTIFICATE-----";
