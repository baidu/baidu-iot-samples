/*
* Copyright (c) 2017 Baidu, Inc. All Rights Reserved.
*
* Licensed to the Apache Software Foundation (ASF) under one or more
* contributor license agreements.  See the NOTICE file distributed with
* this work for additional information regarding copyright ownership.
* The ASF licenses this file to You under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with
* the License.  You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/

#include <azure_c_shared_utility/platform.h>
#include <azure_c_shared_utility/threadapi.h>
//#include <azure_c_shared_utility/uuid.h>

#include "iot_smarthome_callback.h"
#include "iot_smarthome_client.h"
#include "iot_smarthome_client_sample.h"

// Should include serializer to operate shadow with device model.
#include "serializer.h"
#define malloc dna_malloc
#define calloc dna_calloc
#define realloc dna_realloc
#define free dna_free
#define         SPLIT               "--------------------------------------------------------------------------------------------"

// online
//#define         DEVICE              "m593wfa2zx0jfpsa"
#define         DEVICE              "nxe7vvgdw5625vp4"



// $endpointName/$puid
//#define         USERNAME            "e354ef98e333405ebeae893c0006d2b9/m593wfa2zx0jfpsa"

#define         USERNAME            "dc8af98de21a4b3991777e24eec68201/nxe7vvgdw5625vp4"
// if your device is a gateway, you can add subdevice puids here
#define         SUBDEVICE           "7akh0k2hh467xfdc"

/*static char * client_cert = "-----BEGIN CERTIFICATE-----\n"
        "MIIDnDCCAoSgAwIBAgIIJ0Ol13d9Ms0wDQYJKoZIhvcNAQELBQAwMzEWMBQGA1UE\n"
        "AwwNaW90LmJhaWR1LmNvbTEMMAoGA1UECwwDQkNFMQswCQYDVQQGEwJDTjAeFw0x\n"
        "ODAzMzAxMDQ4NDlaFw0yODAzMjcxMDU4MDBaMHAxDjAMBgNVBAoMBUJhaWR1MQsw\n"
        "CQYDVQQGEwJDTjFDMEEGA1UEAww6ZTM1NGVmOThlMzMzNDA1ZWJlYWU4OTNjMDAw\n"
        "NmQyYjkueDV4aW40Z3AubTU5M3dmYTJ6eDBqZnBzYTEMMAoGA1UECwwDQkNFMIGf\n"
        "MA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCt5zdqcXQ1j/xSkUfIF8Jvm0+63Q3O\n"
        "BlR47O22S0bYpNdZ66cLClWIINlt4tYIZmKyQ+/CIX5nfGMQPtKR0rVx3n6MEMA1\n"
        "wgd+vTyEJ5ZpFOrXSaf/Nhb0ME44IORlX+jFO5sdu5CI43JSfGAq0+pGYAbxN3oK\n"
        "YdEjkgWvWHSo0QIDAQABo4H6MIH3MB0GA1UdDgQWBBRejJHZ/VYd+AG2o7Qvt0fI\n"
        "zjHxPzAMBgNVHRMBAf8EAjAAMB8GA1UdIwQYMBaAFN0I5BWf1vz8AWv7jUq31dsF\n"
        "cI9jMHgGA1UdHwRxMG8wbaBroGmGZ2h0dHA6Ly9wa2kuaW92LmJhaWR1YmNlLmNv\n"
        "bS92MS9wa2kvY3JsP2NtZD1jcmwmZm9ybWF0PVBFTSZpc3N1ZXI9Q04lM0Rpb3Qu\n"
        "YmFpZHUuY29tJTJDT1UlM0RCQ0UlMkNDJTNEQ04wDgYDVR0PAQH/BAQDAgXgMB0G\n"
        "A1UdJQQWMBQGCCsGAQUFBwMCBggrBgEFBQcDBDANBgkqhkiG9w0BAQsFAAOCAQEA\n"
        "aXTray97x1+/XQ5ExyHxhCmONxRMHataeFBOJ8ElHLIjAddcbr3R+35mAjINiqFw\n"
        "Tglh01qOdj5vMJIIPvnsSKrwg/lphzQDRk/QbCov68JIPW2vIlcK2xbdMyHPjj+W\n"
        "9AWd+vuoTDACSxl50MsFxGVJNVMUsHNEMZr+WeFzA79HiOHRVlgxWNX+Qdo+peqM\n"
        "T6J6W1kbU2U3PpYs/WEikCA0fyck4a6Ru0mErwvkzBlUfo5EmyqFhSm7Qklfgcv5\n"
        "Jt22VgOWcLr+XdUPkp4S2aBqsgbjdt4N2STIFyA7nVuGTBd2JPi0zfe/hzwURNFl\n"
        "FT1b9+Gv9EEO+amyCmVibA==\n"
        "-----END CERTIFICATE-----\n";

static char * client_key = "-----BEGIN RSA PRIVATE KEY-----\n"
        "MIICWwIBAAKBgQCt5zdqcXQ1j/xSkUfIF8Jvm0+63Q3OBlR47O22S0bYpNdZ66cL\n"
        "ClWIINlt4tYIZmKyQ+/CIX5nfGMQPtKR0rVx3n6MEMA1wgd+vTyEJ5ZpFOrXSaf/\n"
        "Nhb0ME44IORlX+jFO5sdu5CI43JSfGAq0+pGYAbxN3oKYdEjkgWvWHSo0QIDAQAB\n"
        "AoGAQaaJKBj+mv3pbq5D4AkAMSv71HqBLKb9Gs2vC+OtMjpAxkSNQkC7e3GTQ8Wf\n"
        "sXodhljZWXtVgfHWYBqnWb+nGV6xlA2FPlKNu/+SJNl3pjq68D+5YqrpDTcLpZXb\n"
        "Xf2rpB4Odh9GeNfCTBLLIWIWIh9yRdRlcWwR1EcQQxmocEECQQDoHd+zDUJ0f/Av\n"
        "ziiRCG724VLYbISakb5Smjs51Ua3hmQkr5/A8nt9SkDQEjdTSzPr/Ya1Lbs2dppl\n"
        "hjlVzXrZAkEAv8v0poemJVnLu3bb2yFyyvKL+oMrrQ/PUF9E1MFfW78U/TDWUNL3\n"
        "eJAPYqlQqpWSOYzielFMaWSRq4O2RGyyuQJAROXhKaes6yGyrK338pzbOyLE0YLc\n"
        "lXjfUmt/WvpIhF86yHzs4XvYVec9d8WAcJPo9IqLeqn5YQAxciM2T5aveQJAH/Xz\n"
        "0eBe7nB1Q8r9vhln0Kv0aY18NL2itWj6xl1m75n6/Gor/JH7TSrsdWtzlsmP8Wkp\n"
        "wGpVymZI5ATx1ZsreQJAHBOYhYr+sEflO71n2Q+sqDaT+m9lmJoJkEDjlF8rUAwV\n"
        "VweInYJwk0EJPj4qhcCYL9IP9TIOngMDVOXiNqCvjw==\n"
        "-----END RSA PRIVATE KEY-----\n";

*/
static char * client_cert = "-----BEGIN CERTIFICATE-----\nMIIDnDCCAoSgAwIBAgIIc8WJr2o79vAwDQYJKoZIhvcNAQELBQAwMzEWMBQGA1UE\nAwwNaW90LmJhaWR1LmNvbTEMMAoGA1UECwwDQkNFMQswCQYDVQQGEwJDTjAeFw0x\nODAzMzEyMzUyMTFaFw0yODAzMjkwMDAyMDBaMHAxDjAMBgNVBAoMBUJhaWR1MQsw\nCQYDVQQGEwJDTjFDMEEGA1UEAww6ZGM4YWY5OGRlMjFhNGIzOTkxNzc3ZTI0ZWVj\nNjgyMDEuc2hteXJxdnIubnhlN3Z2Z2R3NTYyNXZwNDEMMAoGA1UECwwDQkNFMIGf\nMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCZm29Zv6zRzfdZkYMYouWKvsg4HQPi\nufPtA/xD9YolJ6gInPecrcISB2CsE4ayfSkTT3PNa1OjmSQ4S0xQgfhw2MLjGU5b\nIYWP2TcuqY5O47G0wrGhVIeSqdtO2DpCbKL5PXSbUW+Op7NeszL+uaA9Fx2p5hKk\nID9mrpthYqGB6QIDAQABo4H6MIH3MB0GA1UdDgQWBBT3g1PyplvbNS5tTig5VP3F\nn/8mSjAMBgNVHRMBAf8EAjAAMB8GA1UdIwQYMBaAFN0I5BWf1vz8AWv7jUq31dsF\ncI9jMHgGA1UdHwRxMG8wbaBroGmGZ2h0dHA6Ly9wa2kuaW92LmJhaWR1YmNlLmNv\nbS92MS9wa2kvY3JsP2NtZD1jcmwmZm9ybWF0PVBFTSZpc3N1ZXI9Q04lM0Rpb3Qu\nYmFpZHUuY29tJTJDT1UlM0RCQ0UlMkNDJTNEQ04wDgYDVR0PAQH/BAQDAgXgMB0G\nA1UdJQQWMBQGCCsGAQUFBwMCBggrBgEFBQcDBDANBgkqhkiG9w0BAQsFAAOCAQEA\nQkB2+sd+ASxOpdeStMkrlnxr5hUUd4x7OOiJzDm41EdfUF39iv0EbCYUaSYShly5\nG0qvZhdPOYLtpJ3LrJSnXKa8Jjzo7cS9fCikxzDenwEJzyYDF/IzbSpTLN2Qo4Re\nQvoy4D9ymdaRyPbm8flKLKL/Rz6rr4iDWZpoLfJrCS7CAalPBCpJJIXarJa8f1/d\nAEnDXS1hXWE8utdeR3LX79KR3YMTUZMW6PLKJqkD2Te68b6ThNVQHdut7i9nE+nL\nDpxoVG5DrQaI79FOnpAyaQp1oMF8grFaZEOPyedGtQDujMB7re73IhEEAjR0gKrS\ntySaLSMUcPIktAyhMmQZMA==\n-----END CERTIFICATE-----\n";

static char * client_key = "-----BEGIN RSA PRIVATE KEY-----\nMIICXAIBAAKBgQCZm29Zv6zRzfdZkYMYouWKvsg4HQPiufPtA/xD9YolJ6gInPec\nrcISB2CsE4ayfSkTT3PNa1OjmSQ4S0xQgfhw2MLjGU5bIYWP2TcuqY5O47G0wrGh\nVIeSqdtO2DpCbKL5PXSbUW+Op7NeszL+uaA9Fx2p5hKkID9mrpthYqGB6QIDAQAB\nAoGBAIdrSeqUmdZJP4R+TVX93mHIOhmGMvPCPjK5Lb/4CzcgU/pr77v4T7y3Nlnd\nyQU4ZGr6w7vYn9791rmuYHQlcRElzbYHINvi3CawTLKYqAskW3pUEh9Qt5+4I/a6\n5D7Ca5qBXN8of6z/Fxi6SVjWebOsolX54ESzmcQZu+y8AuWRAkEAyErbXBu7h48p\nIktADnb1oczuFF6CptnWUm67yyyto2rn2um8+Vsg8jL1S/taRGNr3yWmLC+lwk4s\nlVUwCc9lfQJBAMRUg3GvApHU7siGCWgF58cU5XNclRavZTSzfGj751siKqm3teyl\nbyC9lINyIhuybbNik+U+5lWwpP6j7wkTid0CQFjh90SBvg+jNTLVyABjRA/gXErH\nwhz/EIAWSdoY4plhiLB6B3V0vkMc4AQu79jncehd0cdMAbgfbuN6IU5JLhUCQDXS\n8aJGF49BcCE7VfLVw6A5o1oIJLtuZHGZT188yEWczVNwEQkKpbe1IbUTojQzq42F\nVgSARQdzARjqeorjd2UCQFYdquDsvz76rv4fPDPr5cv6SMG1YjUjneE8vA8UaG69\n16zT9O2xEiS61jrWrRYxcKK8e2fCPVquVtOjWkdAyQw=\n-----END RSA PRIVATE KEY-----\n";

static bool isGateway;
// define your own parameters here
BEGIN_NAMESPACE(BaiduIotDeviceSample);

/* DECLARE_MODEL(BaiduSamplePump,
              WITH_DATA(int, FrequencyIn),
              WITH_DATA(int, FrequencyOut),
              WITH_DATA(int, Current),
              WITH_DATA(int, Speed),
              WITH_DATA(int, Torque),
              WITH_DATA(int, Power),
              WITH_DATA(int, DC_Bus_voltage),
              WITH_DATA(int, Output_voltage),
              WITH_DATA(int, Drive_temp)
); */
DECLARE_MODEL(BaiduSamplePump,
              WITH_DATA(int, pwr),
              WITH_DATA(int, color)
);

END_NAMESPACE(BaiduIotDeviceSample);

static void Log(const char* message)
{
    printf("%s\r\n", message);
}

static void Log4Int(const int value)
{
    printf("%d\r\n", value);
}

static void LogCode(const int code)
{
    Log4Int(code);
}

static void LogVersion(const int version)
{
    Log4Int(version);
}

static void LogAcceptedMessage(const SHADOW_ACCEPTED* accepted)
{
    Log("ProfileVersion:");
    LogVersion(accepted->profileVersion);

    JSON_Value* value = json_object_get_wrapping_value(accepted->reported);
    char* encoded = json_serialize_to_string(value);
    Log("Reported:");
    Log(encoded);
    json_free_serialized_string(encoded);

    value = json_object_get_wrapping_value(accepted->desired);
    encoded = json_serialize_to_string(value);
    Log("Desired:");
    Log(encoded);
    json_free_serialized_string(encoded);

    value = json_object_get_wrapping_value(accepted->lastUpdateTime);
    encoded = json_serialize_to_string(value);
    Log("LastUpdateTime:");
    Log(encoded);
    json_free_serialized_string(encoded);
}

static void HandleAccepted(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ACCEPTED* accepted, void* callbackContext)
{
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);

    if (isGateway == true) {
        Log("SubDevice:");
        Log(messageContext->subdevice);
    }

    LogAcceptedMessage(accepted);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }
}

static void HandleRejected(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ERROR* error, void* callbackContext)
{
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);
    if (isGateway == true) {
        Log("SubDevice:");
        Log(messageContext->subdevice);
    }
    Log("Code:");
    LogCode(error->code);
    Log("Message:");
    Log(error->message);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }
}

static void HandleGetAccepted(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ACCEPTED* accepted, void* callbackContext)
{
    Log("Received a message for shadow get accepted.");
    HandleAccepted(messageContext, accepted, callbackContext);

    Log(SPLIT);
}

static void HandleGetRejected(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ERROR* error, void* callbackContext)
{
    Log("Received a message for shadow get rejected.");
    HandleRejected(messageContext, error, callbackContext);

    Log(SPLIT);
}

static void HandleUpdateRejected(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ERROR* error, void* callbackContext)
{
    Log("Received a message for shadow update rejected.");
    HandleRejected(messageContext, error, callbackContext);

    Log(SPLIT);
}

static void HandleUpdateAccepted(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_ACCEPTED* accepted, void* callbackContext)
{
    Log("Received a message for shadow update accepted.");
    HandleAccepted(messageContext, accepted, callbackContext);

    Log(SPLIT);
}

static void HandleUpdateDocuments(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_DOCUMENTS* documents, void* callbackContext)
{
    Log("Received a message for shadow update documents.");
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);
    if (isGateway == true) {
        Log("SubDevice:");
        Log(messageContext->subdevice);
    }
    Log("ProfileVersion:");
    LogVersion(documents->profileVersion);

    JSON_Value* value = json_object_get_wrapping_value(documents->current);
    char* encoded = json_serialize_to_string(value);
    Log("Current:");
    Log(encoded);

    value = json_object_get_wrapping_value(documents->previous);
    encoded = json_serialize_to_string(value);
    Log("Previous:");
    Log(encoded);
    json_free_serialized_string(encoded);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }

    Log(SPLIT);
}

static void HandleUpdateSnapshot(const SHADOW_MESSAGE_CONTEXT* messageContext, const SHADOW_SNAPSHOT* snapshot, void* callbackContext)
{
    Log("Received a message for shadow update snapshot.");
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);
    if (isGateway == true) {
        Log("SubDevice:");
        Log(messageContext->subdevice);
    }
    Log("ProfileVersion:");
    LogVersion(snapshot->profileVersion);

    JSON_Value* value = json_object_get_wrapping_value(snapshot->reported);
    char* encoded = json_serialize_to_string(value);
    Log("Reported:");
    Log(encoded);

    value = json_object_get_wrapping_value(snapshot->lastUpdateTime);
    encoded = json_serialize_to_string(value);
    Log("LastUpdateTime:");
    Log(encoded);
    json_free_serialized_string(encoded);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }

    Log(SPLIT);
}

static void HandleDelta(const SHADOW_MESSAGE_CONTEXT* messageContext, const JSON_Object* desired, void* callbackContext)
{
    Log("Received a message for shadow delta");
    Log("Request ID:");
    Log(messageContext->requestId);
    Log("Device:");
    Log(messageContext->device);
    if (isGateway == true) {
        Log("SubDevice:");
        Log(messageContext->subdevice);
    }
    JSON_Value* value = json_object_get_wrapping_value(desired);
    char* encoded = json_serialize_to_string(value);
    Log("Payload:");
    Log(encoded);
    json_free_serialized_string(encoded);

    if (NULL == callbackContext)
    {
        LogError("Failure: the callback context is NULL.");
    }

    // In the actual implementation, we should adjust the device status to match the control of device.
    // However, here we only sleep, and then update the device shadow (status in reported payload).

    ThreadAPI_Sleep(10);
    IOT_SH_CLIENT_HANDLE handle = (IOT_SH_CLIENT_HANDLE)callbackContext;
    int result = messageContext->subdevice == NULL
                 ? iot_smarthome_client_update_shadow(handle, messageContext->device, messageContext->requestId, 0, value, NULL)
                 : iot_smarthome_client_update_subdevice_shadow(handle, messageContext->device, messageContext->subdevice, messageContext->requestId, 0, value, NULL);
    if (0 == result)
    {
        Log("Have done for the device controller request, and corresponding shadow is updated.");
    }
    else
    {
        LogError("Failure: failed to update device shadow.");
    }

    Log(SPLIT);
}

int iot_smarthome_client_run(bool isGatewayDevice)
{
    isGateway = isGatewayDevice;
    Log("The device management edge simulator is starting ...");
    if (SERIALIZER_OK != serializer_init(NULL))
    {
        Log("serializer_init failed");
        return __FAILURE__;
    }

    IOT_SH_CLIENT_HANDLE handle = iot_smarthome_client_init(isGatewayDevice);
    if (NULL == handle)
    {
        Log("iot_smarthome_client_init failed");
        return __FAILURE__;
    }

    iot_smarthome_client_register_delta(handle, HandleDelta, handle);
    iot_smarthome_client_register_get_accepted(handle, HandleGetAccepted, handle);
    iot_smarthome_client_register_get_rejected(handle, HandleGetRejected, handle);
    iot_smarthome_client_register_update_accepted(handle, HandleUpdateAccepted, handle);
    iot_smarthome_client_register_update_rejected(handle, HandleUpdateRejected, handle);
    iot_smarthome_client_register_update_documents(handle, HandleUpdateDocuments, handle);
    iot_smarthome_client_register_update_snapshot(handle, HandleUpdateSnapshot, handle);

    // do sha256 rsa signature and verification
    unsigned char* data = (unsigned char*)"123456";
    const char* signature = computeSignature(data, client_key);
    if (signature == NULL) {
        LogError("compute Signature failed");
        return __FAILURE__;
    }

    LogInfo("rsa sha256 signature of %s is %s", data, signature);

    int sigRet = verifySignature(data, client_cert, signature);

    if (sigRet == 0) {
        LogInfo("verify signature success");
    }
    else {
        LogError("verify signature fail");
        return __FAILURE__;
    }

    if (0 != iot_smarthome_client_connect(handle, USERNAME, DEVICE, client_cert, client_key))
    {
        iot_smarthome_client_deinit(handle);
        Log("iot_smarthome_client_connect failed");
        return __FAILURE__;
    }

    // Subscribe the topics.
    iot_smarthome_client_dowork(handle);

    // Sample: get device shadow
    int result = isGateway ? iot_smarthome_client_get_subdevice_shadow(handle, DEVICE, SUBDEVICE, "123456789")
                           : iot_smarthome_client_get_shadow(handle, DEVICE, "123456789");
    if (0 == result)
    {
        Log("Succeeded to get device shadow");
    }
    else
    {
        Log("Failed to get device shadow");
    }
  
    // Sample: subscribe the delta topic and update shadow with desired value.
    while (iot_smarthome_client_dowork(handle) >= 0)
    {
	//printf("--------->The free heap is %d byte <---------\r\n", xPortGetFreeHeapSize());
        ThreadAPI_Sleep(1000);
    }

    iot_smarthome_client_deinit(handle);
    serializer_deinit();

    return 0;
}
